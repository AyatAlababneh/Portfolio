﻿using Portfolio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
   public interface IUserSkillRepository
    {
        List<InterpersonalSkill> GetAllInterPersonalSkill();
        List<TechnicalSkill> GetAllTechnicalSkill();
        List<UserTechnicalSkill> GetAllTechnicalSkillById(string id);
        List<UserInterpersonalSkill> GetAllInterPersonalSkillById(string id);
    }
}
