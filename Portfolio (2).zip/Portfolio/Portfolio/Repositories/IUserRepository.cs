﻿using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using Portfolio.Data;
using Portfolio.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
   public interface IUserRepository
    {
      public void AddNewP(UserDto userDto);
      public  User GetUserById(string id);
        //User Edit(string id);
         void UpdatePortfolio(UserDto user);
        public void Remove(string id);

    }
}
