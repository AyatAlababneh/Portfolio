﻿using Portfolio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
    public interface IUserUniDegRepository
    {
        List<University> GetAllUniversity();
        List<Degree> GetAllDegree();
        List<UserUniversityDegree> GetAllUniDegById(string id);


    }
}
