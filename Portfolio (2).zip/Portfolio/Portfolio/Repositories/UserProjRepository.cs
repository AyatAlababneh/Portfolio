﻿using Microsoft.EntityFrameworkCore;
using Portfolio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
    public class UserProjRepository:IUserProjRepository
    {
        private readonly ApplicationDbContext applicationDbContext;
        public UserProjRepository(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
        public List<Project> GetAllProject()
        {
            return applicationDbContext.Projects.ToList();
        }
        public  List<Project> GetAllProjectBuId(string id)
        {
            return applicationDbContext.Projects.Where(x=>x.UserId==id).ToList();
        }
        public Project GetProject(int id)
        {
            return applicationDbContext.Projects.Where(x => x.ProjectId == id).SingleOrDefault();
        }
    }
}
