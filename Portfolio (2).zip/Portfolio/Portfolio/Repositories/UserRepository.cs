﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Portfolio.Data;
using Portfolio.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
    public class UserRepository:IUserRepository
    {
        private readonly ApplicationDbContext applicationDbContext;
        public  UserRepository(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
        public void AddNewP(UserDto userdto)
        {
            var user = applicationDbContext.Users.Where(x => x.Id == userdto.UserId).SingleOrDefault();
            user.FirstName = userdto.FirstName;
            user.SecondName = userdto.SecondName;
            user.LastName = userdto.LastName;
            user.Gender = userdto.Gender;
            user.FacebookUrl = userdto.FacebookUrl;
            user.About = userdto.About;
            user.Address = userdto.Address;
            user.CV = userdto.CV;
            user.DateOfBirth = userdto.DateOfBirth;
            user.LinkedInUrl = userdto.LinkedInUrl;
            user.TwitterUrl = userdto.TwitterUrl;
            user.Vision = userdto.Vision;
            user.PortfolioEmail = userdto.PortfolioEmail;
            user.PhoneNumber = userdto.PhoneNumber;
            user.PersonalImage = userdto.PersonalImage;
            
            applicationDbContext.SaveChanges();

            foreach (var technical in userdto.TechnicalSkills)
            {
                UserTechnicalSkill userTechnicalSkill = new UserTechnicalSkill();
                userTechnicalSkill.UserId = userdto.UserId;
                userTechnicalSkill.UserTechnicalSkillId = technical;
                applicationDbContext.UserTechnicalSkills.Add(userTechnicalSkill);
               

            }
            foreach (var interpersonal in userdto.InterpersonalSkills)
            {
                UserInterpersonalSkill Interpersonal = new UserInterpersonalSkill();
                Interpersonal.UserId = userdto.UserId;
                Interpersonal.UserInterpersonalSkillId = interpersonal;

                applicationDbContext.UserInterpersonalSkills.Add(Interpersonal);
              

            }
            foreach (var uni in userdto.Universities)
            {
                if (uni.DegreeId == 0)
                    break;
                UserUniversityDegree unideg = new UserUniversityDegree();
                unideg.UserId = userdto.UserId;
                unideg.UniversityId = uni.UniversityId;
                unideg.DegreeId = uni.DegreeId;
                unideg.major = uni.major;

                applicationDbContext.UserUniversitieDegrees.Add(unideg);
              

            }
            foreach (var project in userdto.Projects)
            {
                Project pro = new Project();
                pro.UserId = userdto.UserId;
                pro.ProjectId = project.ProjectId;
                pro.ProjectName = project.ProjectName;
                pro.Description = project.Description;
                pro.ProjectImage = project.ProjectImage;
                pro.uploadProject = project.uploadProject;

                applicationDbContext.Projects.Add(pro);
            }
            applicationDbContext.SaveChanges();
        }
      public  User GetUserById(string id)
        {
         return applicationDbContext.Userss.Where(x => x.Id == id).SingleOrDefault();
        }
        public void Remove(string id)
        {
            List<UserTechnicalSkill> UTSkill = applicationDbContext.UserTechnicalSkills.Where(x => x.UserId == id).ToList();
            foreach(var UTS in UTSkill)
            {
                applicationDbContext.Remove(UTS);
            }
            List<UserInterpersonalSkill> UISkill = applicationDbContext.UserInterpersonalSkills.Where(x => x.UserId == id).ToList();
            foreach (var UIS in UISkill)
            {
                applicationDbContext.Remove(UIS);
            }
            List<UserUniversityDegree> UUniDeg = applicationDbContext.UserUniversitieDegrees.Where(x => x.UserId == id).ToList();
            foreach (var UUD in UUniDeg)
            {
                applicationDbContext.Remove(UUD);
            }
            List<Project> UProj = applicationDbContext.Projects.Where(x => x.UserId == id).ToList();
            foreach (var UP in UProj)
            {
                applicationDbContext.Remove(UP);
            }
            var user= applicationDbContext.Userss.Where(x => x.Id == id).SingleOrDefault();
            user.Address = null;
            user.About = null;
            user.CV = null;
            user.SecondName = null;
            user.LastName = null;
            user.LinkedInUrl = null;
            user.TwitterUrl = null;
            user.FacebookUrl = null;
            user.PhoneNumber = null;
            user.PortfolioEmail = null;
            user.Gender =Convert.ToBoolean(null);
            user.PersonalImage = null;
            user.DateOfBirth = Convert.ToDateTime(null);
            user.Vision = null;
            user.FirstName = null;
     
            applicationDbContext.SaveChanges();
        }
       
        public void UpdatePortfolio(UserDto user)
        {
            var users = applicationDbContext.Userss.Where(x => x.Id == user.UserId).SingleOrDefault();
            users.FirstName = user.FirstName;
            users.LastName = user.LastName;
            users.Address = user.Address;
            users.PhoneNumber = user.PhoneNumber;
            users.PortfolioEmail = user.PortfolioEmail;
            users.LinkedInUrl = user.LinkedInUrl;
            users.FacebookUrl = user.FacebookUrl;
            users.TwitterUrl = user.TwitterUrl;
            users.About = user.About;
            users.TwitterUrl = user.TwitterUrl;
            users.Vision = user.Vision;
            users.CV = user.CV;
            users.Gender = user.Gender;
            users.PersonalImage = user.PersonalImage;


            var usertechnical = applicationDbContext.UserTechnicalSkills.Where(x => x.UserId == user.UserId).ToList();
            foreach (var tech in usertechnical)
            {
                applicationDbContext.Remove(tech);
                applicationDbContext.SaveChanges();
            }
            var newusertechnical = new UserTechnicalSkill();
            foreach (var technical in user.TechnicalSkills)
            {
                newusertechnical.UserId = user.UserId;
                newusertechnical.UserTechnicalSkillId = technical;
                applicationDbContext.UserTechnicalSkills.Add(newusertechnical);
                applicationDbContext.SaveChanges();
            }

            var inter = applicationDbContext.UserInterpersonalSkills.Where(x => x.UserId == user.UserId).ToList();
            foreach (var interskill in inter)
            {
                applicationDbContext.Remove(interskill);
                applicationDbContext.SaveChanges();
            }
            var newuserinter = new UserInterpersonalSkill();
            foreach (var skillinter in user.InterpersonalSkills)
            {
                newuserinter.UserId = user.UserId;
                newuserinter.UserInterpersonalSkillId = skillinter;
                applicationDbContext.UserInterpersonalSkills.Add(newuserinter);
                applicationDbContext.SaveChanges();
            }
            var userpro = applicationDbContext.Projects.Where(x => x.UserId == user.UserId).ToList();
            foreach (var pro in userpro)
            {
                applicationDbContext.Remove(pro);
                applicationDbContext.SaveChanges();
            }
            
            foreach (var upro in user.Projects)
            {
                var newpro = new Project();
                newpro.UserId = user.UserId;
                newpro.ProjectId = upro.ProjectId;
                newpro.ProjectImage = upro.ProjectImage;
                newpro.uploadProject = upro.uploadProject;
                newpro.Description = upro.Description;
                newpro.ProjectName = upro.ProjectName;
                applicationDbContext.Add(newpro);
                applicationDbContext.SaveChanges();
            }

            var uni = applicationDbContext.UserUniversitieDegrees.Where(x => x.UserId == user.UserId).ToList();
            foreach (var university in uni)
            {
                applicationDbContext.Remove(university);
                applicationDbContext.SaveChanges();
            }
            var newuni = new UserUniversityDegree();
            foreach (var unii in user.Universities)
            {
                var useruni = new UserUniversityDegree();
                newuni.UserId = user.UserId;
                newuni.UniversityId= unii.UniversityId;
                newuni.DegreeId = unii.DegreeId;
                newuni.major = unii.major;
                applicationDbContext.UserUniversitieDegrees.Add(newuni);
                applicationDbContext.SaveChanges();
            }

        }

    }
}
//public User Edit(string id)
//{
//    var edituser = applicationDbContext.Userss.Include(x=>x.UserInterpersonalSkills).ThenInclude(x=>x.InterpersonalSkill)
//        .Include(x=>x.UserTechnicalSkills).ThenInclude(x=>x.TechnicalSkill)
//        .Include(x => x.UserUniversityDegree).ThenInclude(x => x.University)
//        .Include(x => x.Project).Where(x => x.Id == id).SingleOrDefault();

//    return edituser;
//}