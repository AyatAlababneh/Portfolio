﻿using Microsoft.EntityFrameworkCore;
using Portfolio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
    public class UserUniDegRepository:IUserUniDegRepository
    {
        private readonly ApplicationDbContext applicationDbContext;
        public UserUniDegRepository(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
        public List<University> GetAllUniversity()
        {
            return applicationDbContext.Universites.ToList();
        }
        public List<Degree> GetAllDegree()
        {
            return applicationDbContext.Degrees.ToList();
        }
        public List<UserUniversityDegree> GetAllUniDegById(string id)
        {
            return applicationDbContext.UserUniversitieDegrees.Where(x=>x.UserId==id).ToList();
        }

    }
}
