﻿using Microsoft.EntityFrameworkCore;
using Portfolio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
    public class UserSkillRepository:IUserSkillRepository
    {
        private readonly ApplicationDbContext applicationDbContext;
        public UserSkillRepository(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
       public List<InterpersonalSkill> GetAllInterPersonalSkill()
        {
            return applicationDbContext.InterpersonalSkills.ToList();
        }
        public List<TechnicalSkill> GetAllTechnicalSkill()
        {
            return applicationDbContext.TechnicalSkills.ToList();
        }
        public List<UserInterpersonalSkill> GetAllInterPersonalSkillById(string id)
        {
            return applicationDbContext.UserInterpersonalSkills.Where(x => x.UserId == id).ToList();
        }
        public List<UserTechnicalSkill> GetAllTechnicalSkillById(string id)
        {
            return applicationDbContext.UserTechnicalSkills.Where(x=>x.UserId==id).ToList();
        }
    }
}
