﻿using Portfolio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Repositories
{
   public interface IUserProjRepository
    {
       List<Project> GetAllProject();
       List<Project> GetAllProjectBuId(string id);
        Project GetProject(int id);
    }
}
