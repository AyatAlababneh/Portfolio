﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class TechnicalSkill
    {
        public int TechnicalSkillId { get; set; }
        [Display(Name = "Technical Skill")]
      
        public string TechnicalName { get; set; }
        public bool DeleteTS { get; set; }
        public ICollection<UserTechnicalSkill> UserTechnicalSkills { get; set; }
    }
}
