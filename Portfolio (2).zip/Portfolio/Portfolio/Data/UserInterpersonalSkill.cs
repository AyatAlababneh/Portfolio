﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class UserInterpersonalSkill
    {
        public User User { get; set; }
        public string UserId { get; set; }
        public InterpersonalSkill InterpersonalSkill { get; set; }
        public int UserInterpersonalSkillId { get; set; }
    }
}
