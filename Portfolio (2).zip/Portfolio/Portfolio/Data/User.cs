﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class User:IdentityUser
    {
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        
        [Display(Name = "Second Name")]
        public string SecondName { get; set; }
        
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        
        [Display(Name = "Date of Birth")]
        public DateTime DateOfBirth { get; set; }
        
        [Display(Name = "Portfolio Email")]
        public string PortfolioEmail { get; set; }
        public bool Gender { get; set; }
        
        public string Address { get; set; }
        
        [Display(Name = "Personal Image")]
        public byte[] PersonalImage { get; set; }
        public bool DeleteUser { get; set; }
        
        [Display(Name = "Facebook Url")]
        public string FacebookUrl { get; set; }
        
        [Display(Name = "Twitter Url")]
        public string TwitterUrl { get; set; }
        
        [Display(Name = "LinkedIn Url")]
        public string LinkedInUrl { get; set; }
        public string Vision { get; set; }
        public string About { get; set; }
        public byte[] CV { get; set; }
        public ICollection<UserUniversityDegree> UserUniversityDegree { get; set; }
        public ICollection<Project> Project { get; set; }
        public ICollection<UserInterpersonalSkill> UserInterpersonalSkills { get; set; }
        public ICollection<UserTechnicalSkill> UserTechnicalSkills { get; set; }
    }
}
