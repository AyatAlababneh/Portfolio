﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class Project
    {
        public int ProjectId { get; set; }
        [Display(Name = "Project Image")]
        
        public byte[] ProjectImage { get; set; }
        [Display(Name = "Project Name")]
       
        public string ProjectName { get; set; }
      
        public string Description { get; set; }
     
        [Display(Name = "Upload Project")]
        public byte[] uploadProject { get; set; }
        public bool DeletePrj { get; set; }
        public User User { get; set; }
        public string UserId { get; set; }
    }
}
