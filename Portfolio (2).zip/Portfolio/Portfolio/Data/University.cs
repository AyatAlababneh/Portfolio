﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class University
    {
        public int UniversityId { get; set; }
       
        [Display(Name = "University Name")]
        public string UniversityName { get; set; }
        public bool DeleteUni { get; set; }
        public ICollection<UserUniversityDegree> UserUniversityDegree { get; set; }
    }
}
