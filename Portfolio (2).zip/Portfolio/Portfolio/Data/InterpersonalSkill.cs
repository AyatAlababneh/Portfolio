﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class InterpersonalSkill
    {
        public int InterpersonalSkillId { get; set; }
        [Display(Name = "Interpersonal Skill")]
       
        public string InterpersonalName { get; set; }
        public bool DeleteIpS { get; set; }
        public ICollection<UserInterpersonalSkill> UserInterpersonalSkills { get; set; }
    }
}
