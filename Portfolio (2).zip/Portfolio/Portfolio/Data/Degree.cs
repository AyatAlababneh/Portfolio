﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class Degree
    {
        public int DegreeId { get; set; }
        [Display(Name = "Degree Name")]
    
        public string DegreeName { get; set; }
        public bool DeleteDgr { get; set; }
        public ICollection<UserUniversityDegree> UserUniversityDegree { get; set; }
    }
}
