﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Data
{
    public class UserTechnicalSkill
    {
        public User User { get; set; }
        public string UserId { get; set; }
        public TechnicalSkill TechnicalSkill { get; set; }
        public int UserTechnicalSkillId { get; set; }
    }
}
