﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Portfolio.Data.Migrations
{
    public partial class NewPortfolio : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserInterpersonalSkill_AspNetUsers_UserId",
                table: "UserInterpersonalSkill");

            migrationBuilder.DropForeignKey(
                name: "FK_UserInterpersonalSkill_InterpersonalSkills_UserInterpersonalSkillId",
                table: "UserInterpersonalSkill");

            migrationBuilder.DropForeignKey(
                name: "FK_UserTechnicalSkill_AspNetUsers_UserId",
                table: "UserTechnicalSkill");

            migrationBuilder.DropForeignKey(
                name: "FK_UserTechnicalSkill_TechnicalSkills_UserTechnicalSkillId",
                table: "UserTechnicalSkill");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UserTechnicalSkill",
                table: "UserTechnicalSkill");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UserInterpersonalSkill",
                table: "UserInterpersonalSkill");

            migrationBuilder.RenameTable(
                name: "UserTechnicalSkill",
                newName: "UserTechnicalSkills");

            migrationBuilder.RenameTable(
                name: "UserInterpersonalSkill",
                newName: "UserInterpersonalSkills");

            migrationBuilder.RenameIndex(
                name: "IX_UserTechnicalSkill_UserTechnicalSkillId",
                table: "UserTechnicalSkills",
                newName: "IX_UserTechnicalSkills_UserTechnicalSkillId");

            migrationBuilder.RenameIndex(
                name: "IX_UserInterpersonalSkill_UserInterpersonalSkillId",
                table: "UserInterpersonalSkills",
                newName: "IX_UserInterpersonalSkills_UserInterpersonalSkillId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserTechnicalSkills",
                table: "UserTechnicalSkills",
                columns: new[] { "UserId", "UserTechnicalSkillId" });

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserInterpersonalSkills",
                table: "UserInterpersonalSkills",
                columns: new[] { "UserId", "UserInterpersonalSkillId" });

            migrationBuilder.AddForeignKey(
                name: "FK_UserInterpersonalSkills_AspNetUsers_UserId",
                table: "UserInterpersonalSkills",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserInterpersonalSkills_InterpersonalSkills_UserInterpersonalSkillId",
                table: "UserInterpersonalSkills",
                column: "UserInterpersonalSkillId",
                principalTable: "InterpersonalSkills",
                principalColumn: "InterpersonalSkillId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserTechnicalSkills_AspNetUsers_UserId",
                table: "UserTechnicalSkills",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserTechnicalSkills_TechnicalSkills_UserTechnicalSkillId",
                table: "UserTechnicalSkills",
                column: "UserTechnicalSkillId",
                principalTable: "TechnicalSkills",
                principalColumn: "TechnicalSkillId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserInterpersonalSkills_AspNetUsers_UserId",
                table: "UserInterpersonalSkills");

            migrationBuilder.DropForeignKey(
                name: "FK_UserInterpersonalSkills_InterpersonalSkills_UserInterpersonalSkillId",
                table: "UserInterpersonalSkills");

            migrationBuilder.DropForeignKey(
                name: "FK_UserTechnicalSkills_AspNetUsers_UserId",
                table: "UserTechnicalSkills");

            migrationBuilder.DropForeignKey(
                name: "FK_UserTechnicalSkills_TechnicalSkills_UserTechnicalSkillId",
                table: "UserTechnicalSkills");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UserTechnicalSkills",
                table: "UserTechnicalSkills");

            migrationBuilder.DropPrimaryKey(
                name: "PK_UserInterpersonalSkills",
                table: "UserInterpersonalSkills");

            migrationBuilder.RenameTable(
                name: "UserTechnicalSkills",
                newName: "UserTechnicalSkill");

            migrationBuilder.RenameTable(
                name: "UserInterpersonalSkills",
                newName: "UserInterpersonalSkill");

            migrationBuilder.RenameIndex(
                name: "IX_UserTechnicalSkills_UserTechnicalSkillId",
                table: "UserTechnicalSkill",
                newName: "IX_UserTechnicalSkill_UserTechnicalSkillId");

            migrationBuilder.RenameIndex(
                name: "IX_UserInterpersonalSkills_UserInterpersonalSkillId",
                table: "UserInterpersonalSkill",
                newName: "IX_UserInterpersonalSkill_UserInterpersonalSkillId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserTechnicalSkill",
                table: "UserTechnicalSkill",
                columns: new[] { "UserId", "UserTechnicalSkillId" });

            migrationBuilder.AddPrimaryKey(
                name: "PK_UserInterpersonalSkill",
                table: "UserInterpersonalSkill",
                columns: new[] { "UserId", "UserInterpersonalSkillId" });

            migrationBuilder.AddForeignKey(
                name: "FK_UserInterpersonalSkill_AspNetUsers_UserId",
                table: "UserInterpersonalSkill",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserInterpersonalSkill_InterpersonalSkills_UserInterpersonalSkillId",
                table: "UserInterpersonalSkill",
                column: "UserInterpersonalSkillId",
                principalTable: "InterpersonalSkills",
                principalColumn: "InterpersonalSkillId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserTechnicalSkill_AspNetUsers_UserId",
                table: "UserTechnicalSkill",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_UserTechnicalSkill_TechnicalSkills_UserTechnicalSkillId",
                table: "UserTechnicalSkill",
                column: "UserTechnicalSkillId",
                principalTable: "TechnicalSkills",
                principalColumn: "TechnicalSkillId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
