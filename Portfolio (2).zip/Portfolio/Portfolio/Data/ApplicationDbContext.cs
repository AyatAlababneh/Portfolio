﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Portfolio.Data
{
    public class ApplicationDbContext : IdentityDbContext<User>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<UserInterpersonalSkill>().HasKey(x => new { x.UserId, x.UserInterpersonalSkillId });
            builder.Entity<UserInterpersonalSkill>()
                .HasOne<User>(u => u.User)
                .WithMany(ut => ut.UserInterpersonalSkills)
                .HasForeignKey(u => u.UserId);

            builder.Entity<UserInterpersonalSkill>()
             .HasOne<InterpersonalSkill>(i => i.InterpersonalSkill)
             .WithMany(ut => ut.UserInterpersonalSkills)
             .HasForeignKey(i => i.UserInterpersonalSkillId);

            builder.Entity<UserTechnicalSkill>().HasKey(x => new { x.UserId, x.UserTechnicalSkillId });
            builder.Entity<UserTechnicalSkill>()
                 .HasOne<User>(u => u.User)
                 .WithMany(ut => ut.UserTechnicalSkills)
                 .HasForeignKey(u => u.UserId);

            builder.Entity<UserTechnicalSkill>()
                .HasOne<TechnicalSkill>(t => t.TechnicalSkill)
                .WithMany(ut => ut.UserTechnicalSkills)
                .HasForeignKey(t => t.UserTechnicalSkillId);


            builder.Entity<UserUniversityDegree>().HasKey(x => new { x.UserId, x.UniversityId, x.DegreeId });
            builder.Entity<UserUniversityDegree>()
                .HasOne<User>(u => u.User)
                .WithMany(un => un.UserUniversityDegree)
                .HasForeignKey(u => u.UserId);

            builder.Entity<UserUniversityDegree>()
               .HasOne<University>(u => u.University)
               .WithMany(un => un.UserUniversityDegree)
               .HasForeignKey(u => u.UniversityId);

            builder.Entity<UserUniversityDegree>()
              .HasOne<Degree>(d => d.Degree)
              .WithMany(un => un.UserUniversityDegree)
              .HasForeignKey(d => d.DegreeId);

            builder.Entity<Project>()
                .HasOne<User>(u => u.User)
                .WithMany(p => p.Project)
                .HasForeignKey(u => u.UserId);
        }
        public DbSet<User> Userss { get; set; }
        public DbSet<InterpersonalSkill> InterpersonalSkills { get; set; }
        public DbSet<TechnicalSkill> TechnicalSkills { get; set; }
        public DbSet<University> Universites { get; set; }
        public DbSet<Degree> Degrees { get; set; }
        public DbSet<UserUniversityDegree> UserUniversitieDegrees { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<UserInterpersonalSkill> UserInterpersonalSkills { get; set; }
        public DbSet<UserTechnicalSkill> UserTechnicalSkills { get; set; }

    }
}
