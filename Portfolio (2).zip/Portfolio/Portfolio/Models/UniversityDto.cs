﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Models
{
    public class UniversityDto
    {
        public int UniversityId { get; set; }
       
        public int DegreeId { get; set; }
        
        public string major { get; set; }
    }
}
