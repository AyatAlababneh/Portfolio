﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Portfolio.Models
{
    public class UserDto
    {
        public string UserId { get; set; }
        [Required]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }
        [Required]
        [Display(Name = "Second Name")]
        public string SecondName { get; set; }
        [Required]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Required]
        [Display(Name = "Date of Birth")]
        public DateTime DateOfBirth { get; set; }
        [Required]
        [Display(Name = "Portfolio Email")]
        public string PortfolioEmail { get; set; }
        public bool Gender { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        [Display(Name = "Personal Image")]
        public IFormFile PersonalImg { get; set; }
        public byte[] PersonalImage { get; set; }
        [Required]
        [Display(Name ="Phone Number")]
        public string PhoneNumber { get; set; }
       
        public string Vision { get; set; }
        public string About { get; set; }
        [Required]
        public IFormFile CVUpload { get; set; }
       
        public byte[] CV { get; set; }
        [Required]
        [Display(Name = "Facebook Url")]
        public string FacebookUrl { get; set; }
        [Required]
        [Display(Name = "Twitter Url")]
        public string TwitterUrl { get; set; }
        [Required]
        [Display(Name = "LinkedIn Url")]
        public string LinkedInUrl { get; set; }
        public List<int> InterpersonalSkills { get; set; }
        public List<int> TechnicalSkills { get; set; }
        public List<ProjectDto> Projects { get; set; }
        public List<UniversityDto> Universities { get; set; }
    }
}
