﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Portfolio.Data;

namespace Portfolio.Controllers
{
    public class SkillController : Controller
    {
        private readonly ApplicationDbContext applicationDbContext;
        public SkillController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
        public IActionResult InterpersonalSkill()
        {
            var interpersonalSkill = applicationDbContext.InterpersonalSkills.ToList();
            ViewBag.Interpersonal = interpersonalSkill;
            return View();
        }
        public IActionResult CreateInterpersonalSkill()
        {
            return View();
        }
        public IActionResult CreateNInterpersonalSkill(InterpersonalSkill interpersonal)
        {

            InterpersonalSkill interpersonalSkill = new InterpersonalSkill()
            {
                InterpersonalName = interpersonal.InterpersonalName,
               
            };
            applicationDbContext.InterpersonalSkills.Add(interpersonalSkill);
            applicationDbContext.SaveChanges();
            return RedirectToAction("InterpersonalSkill","Skill");

        }
     
        public IActionResult EditInterPersonalSkill(int id)
        {
            var interpersonal = applicationDbContext.InterpersonalSkills.Where(x => x.InterpersonalSkillId == id).SingleOrDefault();
         
           
            return View(interpersonal);
        }
        public IActionResult UpdateInterpersonalSkill(Data.InterpersonalSkill interpersonal)
        {
            var inter = applicationDbContext.InterpersonalSkills.
                Where(x => x.InterpersonalSkillId == interpersonal.InterpersonalSkillId).SingleOrDefault();

            inter.InterpersonalName = interpersonal.InterpersonalName;
            inter.InterpersonalSkillId = interpersonal.InterpersonalSkillId;

            applicationDbContext.SaveChanges();
            return RedirectToAction("InterpersonalSkill","Skill");
        }
        public IActionResult DeleteInterpersonalSkill(int id)
        {
            var skill = applicationDbContext.InterpersonalSkills.Where(x => x.InterpersonalSkillId == id).SingleOrDefault();
            applicationDbContext.InterpersonalSkills.Remove(skill);
            applicationDbContext.SaveChanges();
            return RedirectToAction("InterpersonalSkill", "Skill");
        }
        public IActionResult TechnicalSkill()
        {
            var technicalSkill = applicationDbContext.TechnicalSkills.ToList();
            ViewBag.Technical = technicalSkill;
            return View();
        }
        public IActionResult CreateTechnicalSkill()
        {
            return View();
        }
        public IActionResult CreateNTechnicalSkill(TechnicalSkill technical)
        {
            TechnicalSkill technicalSkill = new TechnicalSkill()
            {
                TechnicalName = technical.TechnicalName,

            };
            applicationDbContext.TechnicalSkills.Add(technicalSkill);
            applicationDbContext.SaveChanges();
            return RedirectToAction("TechnicalSkill","Skill");

        }
        public IActionResult EditTechnicalSkill(int id)
        {
            var technical = applicationDbContext.TechnicalSkills.Where(x => x.TechnicalSkillId == id).SingleOrDefault();
           
            return View(technical);
        }
        public IActionResult UpdateTechnicalSkill(TechnicalSkill technicalSkill)
        {
            var TechnicalSkill = applicationDbContext.TechnicalSkills.
               Where(x => x.TechnicalSkillId == technicalSkill.TechnicalSkillId).SingleOrDefault();

            TechnicalSkill.TechnicalName = technicalSkill.TechnicalName;
            TechnicalSkill.TechnicalSkillId = technicalSkill.TechnicalSkillId;

            applicationDbContext.SaveChanges();
            return RedirectToAction("TechnicalSkill","Skill");
        }
        public IActionResult DeleteTechnicalSkill(int id)
        {
            var technicalSkill = applicationDbContext.TechnicalSkills.Where(x => x.TechnicalSkillId == id).SingleOrDefault();
            applicationDbContext.TechnicalSkills.Remove(technicalSkill);
            applicationDbContext.SaveChanges();
            return RedirectToAction("TechnicalSkill","Skill");
        }

    }
}
