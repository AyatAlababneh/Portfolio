﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Portfolio.Data;
using Portfolio.Models;
using Portfolio.Repositories;

namespace Portfolio.Controllers
{
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class UserController : Controller
    {
        private readonly IUserRepository userRepository;
        private readonly IUserProjRepository userProjRepository;
        private readonly IUserUniDegRepository userUniDegRepository;
        private readonly IUserSkillRepository userSkillRepository;
        public UserController(IUserRepository userRepository, IUserProjRepository userProjRepository, IUserUniDegRepository userUniDegRepository, IUserSkillRepository userSkillRepository)
        {
            this.userRepository = userRepository;
            this.userProjRepository = userProjRepository;
            this.userUniDegRepository = userUniDegRepository;
            this.userSkillRepository = userSkillRepository;
        }
        [Authorize]
        [HttpGet]
        public IActionResult Create()
        {
            var InterPersonalSkill = userSkillRepository.GetAllInterPersonalSkill();
            ViewBag.PersonalSkill = InterPersonalSkill;
            var TechnicalSkill = userSkillRepository.GetAllTechnicalSkill();
            ViewBag.TechnicalSkill = TechnicalSkill;
            var Uni = userUniDegRepository.GetAllUniversity();
            ViewBag.Uni = Uni;
            var degree = userUniDegRepository.GetAllDegree();
            ViewBag.Degree = degree;
            var Project = userProjRepository.GetAllProject();
            ViewBag.Project = Project;
            return View();
        }

        [HttpPost]
        public IActionResult Create([FromForm] UserDto userdto)
        {
            userdto.UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userdto.PersonalImg.Length > 0)
            {
                Stream st = userdto.PersonalImg.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.PersonalImage = binary.ReadBytes((int)st.Length);
                }
            }
            if (userdto.CVUpload.Length > 0)
            {
                Stream st = userdto.CVUpload.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.CV = binary.ReadBytes((int)st.Length);
                }
            }
            if (userdto.Projects[0].ProjectFile.Length > 0)
            {
                Stream st = userdto.Projects[0].ProjectFile.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.Projects[0].uploadProject = binary.ReadBytes((int)st.Length);
                }
            }
            if (userdto.Projects[0].ProjectImg.Length > 0)
            {
                Stream st = userdto.Projects[0].ProjectImg.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.Projects[0].ProjectImage = binary.ReadBytes((int)st.Length);
                }
            }

            userRepository.AddNewP(userdto);
            using (var message = new MailMessage())
            {
                message.To.Add(new MailAddress(userdto.PortfolioEmail));
                message.From = new MailAddress("Ayat.Alababneh@htu.edu.jo");
                message.Subject = "Portfolio website";
                message.Body = $"Dear {userdto.FirstName},<br/><span style='color:#a92330;'>The portfolio</span> has been created for you at https://ayatportfolio.azurewebsites.net/" +
                    $" .<br/>Your current username : {userdto.PortfolioEmail}<br/>Your Portfolio link : https://ayatportfolio.azurewebsites.net/api/User/ShowPortfolio/{userdto.UserId} " +
                    $"<br/>You can update your portfolio, just visit us.<br/><h4 style='font-family:monospace;'>Best Regardes," +
                    $"<br>Portfolio Management : Ayat <span style='color:#a92330;'>Alababneh</span>";
                message.IsBodyHtml = true;
                using (var smtpClient = new SmtpClient("smtp.office365.com", 587))
                {
                    smtpClient.EnableSsl = true;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential("Ayat.Alababneh@htu.edu.jo", "Ay@13100t@");
                    smtpClient.Send(message);
                }
            }
            return RedirectToAction("ShowPortfolio", "User");
        }
        public IActionResult ShowPortfolio()
        {
            
            var userid = User.FindFirstValue(ClaimTypes.NameIdentifier);
           
            var user = userRepository.GetUserById(userid);
            if (user.FirstName == null)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.user = user;
            var useruniversity = userUniDegRepository.GetAllUniDegById(userid);
            ViewBag.useruni = useruniversity;
            var deg = userUniDegRepository.GetAllDegree();
            ViewBag.degree = deg;
            var uni = userUniDegRepository.GetAllUniversity();
            ViewBag.university = uni;
            var userinterpersonalSkill = userSkillRepository.GetAllInterPersonalSkillById(userid);
            ViewBag.interskill = userinterpersonalSkill;
            var interpersonal = userSkillRepository.GetAllInterPersonalSkill();
            ViewBag.inter = interpersonal;
            var technical = userSkillRepository.GetAllTechnicalSkill();
            ViewBag.tech = technical;
            var usertechnicalSkill = userSkillRepository.GetAllTechnicalSkillById(userid);
            ViewBag.techskill = usertechnicalSkill;
            var userproject = userProjRepository.GetAllProjectBuId(userid);
            ViewBag.project = userproject;
            return View();
        }
        [HttpGet]
        public IActionResult Edit(string id)
        {
            string userid = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var user = userRepository.GetUserById(id);

            var technical = userSkillRepository.GetAllTechnicalSkill();
            ViewBag.tech = technical;
            ViewData["Gender"] = user.Gender;
            var interpersonal = userSkillRepository.GetAllInterPersonalSkill();
            ViewBag.inter = interpersonal;
            var uni = userUniDegRepository.GetAllUniversity();
            ViewBag.university = uni;
            var deg = userUniDegRepository.GetAllDegree();
            ViewBag.degree = deg;

            UserDto userdto = new UserDto()
            {
                FirstName = user.FirstName,
                SecondName=user.SecondName,
                LastName=user.LastName,
                DateOfBirth=user.DateOfBirth,
                Address=user.Address,
                About=user.About,
                FacebookUrl=user.FacebookUrl,
                TwitterUrl=user.TwitterUrl,
                LinkedInUrl=user.LinkedInUrl,
                Vision=user.Vision,
                Gender=user.Gender,
                PortfolioEmail=user.PortfolioEmail,
                PhoneNumber=user.PhoneNumber
            };
            return View(userdto);
          
        }
    
        public IActionResult Update([FromForm] UserDto userdto)
        {
            userdto.UserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userdto.PersonalImg.Length > 0)
            {
                Stream st = userdto.PersonalImg.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.PersonalImage = binary.ReadBytes((int)st.Length);
                }
            }
            if (userdto.CVUpload.Length > 0)
            {
                Stream st = userdto.CVUpload.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.CV = binary.ReadBytes((int)st.Length);
                }
            }
            if (userdto.Projects[0].ProjectFile.Length > 0)
            {
                Stream st = userdto.Projects[0].ProjectFile.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.Projects[0].uploadProject = binary.ReadBytes((int)st.Length);
                }
            }
            if (userdto.Projects[0].ProjectImg.Length > 0)
            {
                Stream st = userdto.Projects[0].ProjectImg.OpenReadStream();
                using (BinaryReader binary = new BinaryReader(st))
                {
                    userdto.Projects[0].ProjectImage = binary.ReadBytes((int)st.Length);
                }
            }

           userRepository.UpdatePortfolio(userdto);
            using (var message = new MailMessage())
            {
                message.To.Add(new MailAddress(userdto.PortfolioEmail));
                message.From = new MailAddress("Ayat.Alababneh@htu.edu.jo");
                message.Subject = "Portfolio website";
                message.Body = $"Dear {userdto.FirstName},<br/>A new<span style='color:#a92330;'> portfolio</span> has been created for you at https://ayatportfolio.azurewebsites.net/" +
                    $" .<br/>Your current username : {userdto.PortfolioEmail}<br/>Your Portfolio link : https://ayatportfolio.azurewebsites.net/api/User/ShowPortfolio/{userdto.UserId} " +
                    $"<br/>You can update your portfolio, just visit us.<br/><h4 style='font-family:monospace;'>Best Regardes," +
                    $"<br>Portfolio Management : Ayat <span style='color:#a92330;'>Alababneh</span>";
                message.IsBodyHtml = true;
                using (var smtpClient = new SmtpClient("smtp.office365.com", 587))
                {
                    smtpClient.EnableSsl = true;
                    smtpClient.UseDefaultCredentials = false;
                    smtpClient.Credentials = new NetworkCredential("Ayat.Alababneh@htu.edu.jo", "Ay@13100t@");
                    smtpClient.Send(message);
                }
            }
            return RedirectToAction("ShowPortfolio", "User");
        }
      
        public IActionResult Delete(string id)
        {
            userRepository.Remove(id);
            return RedirectToAction("Index", "Home");
        }
        [HttpGet]
        public FileStreamResult GetCV(string Id)

            { 
                var user = userRepository.GetUserById(Id);
                 var file = user.CV;
                Stream stream = new MemoryStream(file);
                return new FileStreamResult(stream,"application/pdf");
            }

            public FileStreamResult GetProjectFile(int Id)
                {
                    var project = userProjRepository.GetProject(Id);
                    var file = project.uploadProject;
                    Stream stream = new MemoryStream(file);
                    return new FileStreamResult(stream, "application/pdf");
                }
        [HttpGet]
        public async Task<JsonResult> Show()
        {
            var userid = User.FindFirstValue(ClaimTypes.NameIdentifier);
            User user = userRepository.GetUserById(userid);
            var universityList = userUniDegRepository.GetAllUniDegById(userid);
            var interpersonalSkillList = userSkillRepository.GetAllInterPersonalSkillById(userid);
            var technicalSkillList = userSkillRepository.GetAllTechnicalSkillById(userid);
            var projectList = userProjRepository.GetAllProjectBuId(userid);
            var newUser = new
            {
                firstName = user.FirstName,
                secondName = user.SecondName,
                lastName = user.LastName,
                about = user.About,
                address = user.Address,
                mobilePhone = user.PhoneNumber,
                portfoiloEmail = user.PortfolioEmail,
                gender = user.Gender,
                dateOfBirth = user.DateOfBirth,
                facebook = user.FacebookUrl,
                twitter = user.TwitterUrl,
                linkedIn = user.LinkedInUrl,
                vision = user.Vision,
                personalImage = user.PersonalImage,
                Universities = universityList,
                interpersonalSkills = interpersonalSkillList,
                technicalSkills = technicalSkillList,
                projects = projectList,
            };
            return Json(newUser);
        }
    }
}
