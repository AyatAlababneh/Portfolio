﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Portfolio.Data;

namespace Portfolio.Controllers
{
    public class DegreeController : Controller
    {
        private readonly ApplicationDbContext applicationDbContext;
        public DegreeController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext = applicationDbContext;
        }
        public IActionResult ShowDegree()
        {
            var degree = applicationDbContext.Degrees.ToList();
            ViewBag.Degree = degree;
            return View();
        }
        public IActionResult CreateDegree()
        {
            return View();
        }
        public IActionResult CreateNDegree(Degree degree)
        {
            Degree deg = new Degree()
            {
                DegreeName = degree.DegreeName,

            };
            applicationDbContext.Degrees.Add(deg);
            applicationDbContext.SaveChanges();
            return RedirectToAction("ShowDegree");
        }
        public IActionResult EditDegree(int id)
        {
            var degree = applicationDbContext.Degrees.Where(x => x.DegreeId == id).SingleOrDefault();
           
            return View(degree);
        }
        public IActionResult UpdateDegree(Degree Deg)
        {
            var degree = applicationDbContext.Degrees.Where(x => x.DegreeId == Deg.DegreeId).SingleOrDefault();
            degree.DegreeName = Deg.DegreeName;
            degree.DegreeId = Deg.DegreeId;
            applicationDbContext.SaveChanges();
            return RedirectToAction("ShowDegree");
        }
        public IActionResult DeleteDegree(int id)
        {
            var degree = applicationDbContext.Degrees.Where(x => x.DegreeId == id).SingleOrDefault();
            applicationDbContext.Degrees.Remove(degree);
            applicationDbContext.SaveChanges();
            return RedirectToAction("ShowDegree", "Degree");
        }
    }
}
