﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Portfolio.Data;

namespace Portfolio.Controllers
{
    public class UniversityController : Controller
    {
        private readonly ApplicationDbContext applicationDbContext;
        public UniversityController(ApplicationDbContext applicationDbContext)
        {
            this.applicationDbContext= applicationDbContext;
        }
        public IActionResult ShowUni ()
        {
            var uni = applicationDbContext.Universites.ToList();
            ViewBag.uni = uni;
            return View();
        }
        public IActionResult CreateUni()
        {
            return View();
        }
        public IActionResult CreateNUni(University university)
        {
            University uni = new University()
            {
                UniversityName = university.UniversityName,

            };
            applicationDbContext.Universites.Add(uni);
            applicationDbContext.SaveChanges();

            return RedirectToAction("ShowUni","University");
        }
        public IActionResult EditUni(int id)
        {
            var uni = applicationDbContext.Universites.Where(x => x.UniversityId == id).SingleOrDefault();
            return View(uni);
        }
        public IActionResult UpdateUni(University university)
        {
            var uni = applicationDbContext.Universites.Where(x => x.UniversityId == university.UniversityId).SingleOrDefault();
            uni.UniversityName = university.UniversityName;
            uni.UniversityId = university.UniversityId;
            applicationDbContext.SaveChanges();
            return RedirectToAction("ShowUni","University");
        }
        public IActionResult DeleteUniversity(int id)
        {
            var uni = applicationDbContext.Universites.Where(x => x.UniversityId == id).SingleOrDefault();
            applicationDbContext.Universites.Remove(uni);
            applicationDbContext.SaveChanges();
            return RedirectToAction("ShowUni", "University");
        }
    }
}
